package com.ssd.appssd.objects;

public class User {

    private String nombre;

    public User() {

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
